//
//  PokemonSearchTableViewController.swift
//  Pokedex
//
//  Created by Lambda_School_Loaner_151 on 9/13/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import UIKit

class PokemonSearchTableViewController: UIViewController {
    
    private var pokemonNames: [String] = []
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var abilitiesLabel: UILabel!
    @IBOutlet weak var savePokemonButton: UIButton!
    @IBOutlet weak var searchBox: UISearchBar!
    
    let apiResults = APIController()
    
    var pokemon: Pokemon?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        reloadData()
    }
    
    func reloadData() {
        if let pokemon = pokemon {
            nameLabel.text = pokemon.name
            idLabel.text = "\(pokemon.id)"
            typeLabel.text = "\(pokemon.types)"
        } else {
            self.nameLabel.text = pokemon?.name
            idLabel.text = "\(String(describing: pokemon?.id))"
            typeLabel.text = "\(String(describing: pokemon?.types))"
            // set everything equal to empty
        }
    }

    @IBAction func savePokemonButton(_ sender: Any) {
    }
}

extension PokemonSearchTableViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        print("we have an error")
        guard let searchTerm = searchBar.text else {
            print("No text found in the searchbar")
            return
        }
        apiResults.searchForPokemon(with: searchTerm) { (Pokemon, Error) in
            if let error = Error {
                print(error.localizedDescription)
                return
            }
            // in this we are calling the property of what we are trying to get to, when setting your paramaters, you have to use objects of the same type (i.e string = string, not string = Int)
            if let mySearchResults = Pokemon {
                self.pokemon = mySearchResults
                DispatchQueue.main.async {
                    self.nameLabel?.text
                }
            }
        }
    }
}
