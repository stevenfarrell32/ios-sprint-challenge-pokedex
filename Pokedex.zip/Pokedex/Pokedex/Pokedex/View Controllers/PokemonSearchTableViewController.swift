//
//  PokemonSearchTableViewController.swift
//  Pokedex
//
//  Created by Lambda_School_Loaner_151 on 9/13/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import UIKit


class PokemonSearchTableViewController: UIViewController {
    
    private var pokemonNames: [String] = []
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var abilitiesLabel: UILabel!
    @IBOutlet weak var savePokemonButton: UIButton!
    @IBOutlet weak var searchBox: UISearchBar!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    

    @IBAction func savePokemonButton(_ sender: Any) {
    }
    
//    private func updateViews(with pokemon: Pokemon) {
//        nameLabel.text = pokemon.name
//        typeLabel.text = pokemon.types
//        abilitiesLabel.text = pokemon.abilities
//    }
}
