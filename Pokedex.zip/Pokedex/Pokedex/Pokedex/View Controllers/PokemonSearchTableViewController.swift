//
//  PokemonSearchTableViewController.swift
//  Pokedex
//
//  Created by Lambda_School_Loaner_151 on 9/13/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import UIKit


class PokemonSearchTableViewController: UIViewController {
    
    private var pokemonNames: [String] = []
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var abilitiesLabel: UILabel!
    @IBOutlet weak var savePokemonButton: UIButton!
    @IBOutlet weak var searchBox: UISearchBar!
    
    var apiResults: APIController?
    
    
    var pokemon: Pokemon?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // this sets the delegate (walkie talkie) and assigns it to the view controller allowing it to communicate (send the information to it)
        searchBox.delegate = self
        reloadData()
    }
    
    // this is where we are getting the image from the server
    func fetchImageFromServer(pokemon: Pokemon) {
        let fetchURL = URL(string: pokemon.sprites.front_default)!
        apiResults!.fetchImage(with: fetchURL) { (data, error) in
            if let error = error {
                print(error.localizedDescription)
                return
            }
            if let data = data {
                DispatchQueue.main.async {
                    let decodedImage = UIImage(data: data)
                    self.imageView.image = decodedImage
                    self.reloadData()
                }
            }
        }
    }
    
    func reloadData() {
        if let pokemon = pokemon {
            nameLabel.text = pokemon.name
            fetchImageFromServer(pokemon: pokemon)
            idLabel.text = "\(pokemon.id)"
            let types = pokemon.types.map { $0.type.name }.joined(separator: ", ")
            typeLabel.text = "Types: \(types)"
            
            let abilities = pokemon.abilities.map { $0.ability.name }.joined(separator: ", ")
            abilitiesLabel.text = "Abilities: \(abilities)"
            
        } else {
            nameLabel.text = ""
            idLabel.text = ""
            typeLabel.text = ""
            abilitiesLabel.text = ""
            savePokemonButton.isHidden = false
            // set everything equal to empty
        }
    }

    @IBAction func savePokemonButton(_ sender: Any) {
        if let pokemon = pokemon,
            let apiResults = apiResults {
            print(pokemon)
            apiResults.saveMyPokemon(with: pokemon)
            self.navigationController?.popToRootViewController(animated: true)
        }
    }
}


extension PokemonSearchTableViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        print("we have an error")
        guard let searchTerm = searchBar.text else {
            print("No text found in the searchbar")
            return
        }
        // once w
        apiResults!.searchForPokemon(with: searchTerm) { (Pokemon, Error) in
            if let error = Error {
                print(error.localizedDescription)
                return
            }
            // in this we are calling the property of what we are trying to get to, when setting your paramaters, you have to use objects of the same type (i.e string = string, not string = Int)
            if let mySearchResults = Pokemon {
                self.pokemon = mySearchResults
                print(self.pokemon)
                DispatchQueue.main.async {
                    self.reloadData()
                }
            }
        }
    }
}

