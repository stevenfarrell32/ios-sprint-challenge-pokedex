//
//  Pokemon.swift
//  Pokedex
//
//  Created by Lambda_School_Loaner_151 on 9/13/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import Foundation

struct Pokemon: Codable {
    let name: String
    let ID: Int
    let types: Date
    let abilities: String
}
