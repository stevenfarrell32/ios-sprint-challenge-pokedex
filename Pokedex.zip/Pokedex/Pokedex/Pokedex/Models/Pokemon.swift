//
//  Pokemon.swift
//  Pokedex
//
//  Created by Lambda_School_Loaner_151 on 9/13/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import Foundation


struct Pokemon: Codable {
    var abilities: [AbilityRoot]
    let id: Int
    let types: [TypesRoot]
    let name: String
    var sprites: Sprites
}

struct Sprites: Codable {
    var front_default: String
}

struct AbilityRoot: Codable {
    var ability: Ability
}

struct Ability: Codable {
    var name: String
}

struct TypesRoot: Codable {
    var type: TypeName
}

struct TypeName: Codable {
    var name: String
}

