//
//  Pokemon Controller.swift
//  Pokedex
//
//  Created by Lambda_School_Loaner_151 on 9/13/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import Foundation

import Foundation
// parent object
struct PokemonNames: Codable {
    let results: [SearchResult]
}
// this struct contains the information of whats in the array in our Parent struct of SearchResults
struct SearchResult: Codable {
    var abilities: [AbilityRoot]
    let id: Int
    let types: [TypesRoot]
    let name: String
    var sprites: Sprites
}
