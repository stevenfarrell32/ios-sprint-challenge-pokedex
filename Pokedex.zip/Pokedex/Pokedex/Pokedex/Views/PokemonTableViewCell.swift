//
//  PokemonTableViewCell.swift
//  Pokedex
//
//  Created by Lambda_School_Loaner_151 on 9/13/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import UIKit

class PokemonTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
