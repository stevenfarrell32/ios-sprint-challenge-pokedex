//
//  APIController.swift
//  Pokedex
//
//  Created by Lambda_School_Loaner_151 on 9/15/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import Foundation
import UIKit

class APIController {
    private let baseUrl = URL(string: "http://poke-api.vapor.cloud/")!
    var pokemon: [Pokemon] = []
    enum HTTPMethod: String {
        case get = "GET"
        case post = "POST"
    }
    //this entire block is what will get our pokemon to show up when we search
    // will return the base url if there is one, otherwise it will not go to the next step of code
    //line 22 is what we will be using in our new object decoder to try and get data, either will return data or will return an error
    func searchForPokemon(with searchTerm: String, completion: @escaping (Pokemon? ,Error?) -> Void) {
        
        var urlComponents = URLComponents(url: baseUrl, resolvingAgainstBaseURL: true)
        let searchTermQueryItem = URLQueryItem(name: "search", value: searchTerm)
        urlComponents?.queryItems = [searchTermQueryItem]
        //makes sure we can actually get our url from the url components, if we can get it we go to the next portio of code
        guard let requestURL = urlComponents?.url else {
            print("request URL has no value")
            return
        }
        
        //creates a variable to call our URLRequest function
        var request = URLRequest(url: requestURL)
        request.httpMethod = HTTPMethod.get.rawValue
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
            completion(nil, error)
            return
            }
            guard let data = data else {
                print("no data")
                return
            }
            
            let decoder = JSONDecoder()
            
            do {
                let data = try decoder.decode(Pokemon.self, from: data)
                print(data.name)
                completion(data, nil)
            }catch{
                completion(nil, error)
                return
            }
            
        }.resume()
        
    }

}
