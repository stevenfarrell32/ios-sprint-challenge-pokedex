//
//  APIController.swift
//  Pokedex
//
//  Created by Lambda_School_Loaner_151 on 9/15/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import Foundation
import UIKit

class APIController {
    private let baseUrl = URL(string: "https://pokeapi.co/api/v2")!
    var pokemon: [Pokemon] = []
    enum HTTPMethod: String {
        case get = "GET"
        case post = "POST"
    }
    //this entire block is what will get our pokemon to show up when we search
    // will return the base url if there is one, otherwise it will not go to the next step of code
    //line 22 is what we will be using in our new object decoder to try and get data, either will return data or will return an error
    func searchForPokemon(with searchTerm: String, completion: @escaping (Pokemon? ,Error?) -> Void) {
        
        // this is our URL, takes our constant (pokemonURL) and appends the search term at the end of the full url we are getting our information from
        let pokemonURL = baseUrl.appendingPathComponent("pokemon/\(searchTerm.lowercased())")
        print(pokemonURL)
        
        // creates a catch to get our data, if we can not get data it will not continue to go through the higher blocks of code
        // this is our HTTPMethod that is communicating with the server to get our information that we are searching for
        var request = URLRequest(url: pokemonURL)
        request.httpMethod = HTTPMethod.get.rawValue
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
            completion(nil, error)
            return
            }
            guard let data = data else {
                print("no data")
                return
            }
            let decoder = JSONDecoder()
            
            do {
                let data = try decoder.decode(Pokemon.self, from: data)
                print(data.name)
                completion(data, nil)
            }catch{
                completion(nil, error)
                return
            }
        }.resume()
    }
    // URL is the rule, url is the variable that we are passing our actual "URL" into. url is what we use throughout to call in our functions
    func fetchImage(with url: URL, completion: @escaping (Data?, Error?) -> Void)  {
        var imageRequest = URLRequest(url: url)
        imageRequest.httpMethod = HTTPMethod.get.rawValue
        
        URLSession.shared.dataTask(with: imageRequest) {data, _, error in
            completion(data, error)
        }.resume()
    }
    
    func saveMyPokemon(with pokemon: Pokemon) {
        self.pokemon.append(pokemon)
        print(self.pokemon)
    }
}
