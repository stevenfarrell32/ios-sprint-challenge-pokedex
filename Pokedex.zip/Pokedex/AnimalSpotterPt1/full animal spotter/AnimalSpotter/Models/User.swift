//
//  User.swift
//  AnimalSpotter
//
//  Created by Joe on 9/9/19.
//  Copyright © 2019 Lambda School. All rights reserved.
//

import Foundation

struct User: Codable {
    let username: String
    let password: String
}
