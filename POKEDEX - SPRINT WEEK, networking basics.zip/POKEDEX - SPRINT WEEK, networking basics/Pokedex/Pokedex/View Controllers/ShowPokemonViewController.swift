//
//  ShowPokemonViewController.swift
//  Pokedex
//
//  Created by Lambda_School_Loaner_151 on 9/13/19.
//  Copyright © 2019 Lambda_School_Loaner_151. All rights reserved.
//

import UIKit

class ShowPokemonViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    let apiController = APIController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        print("hello")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("We are searching for the pokemon")
        tableView.reloadData()
        print(apiController.pokemon)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "PokemonSearch" {
            
            guard let destinationVC = segue.destination as? PokemonSearchTableViewController else { return }
            destinationVC.apiResults = apiController
            
        } else if segue.identifier == "ViewPokemon" {
            
            guard let destinationVC = segue.destination as? PokemonSearchTableViewController,
                let indexPath = tableView.indexPathForSelectedRow else { return }
            
            destinationVC.apiResults = apiController
            destinationVC.pokemon = apiController.pokemon[indexPath.row]
        }
    }
    
}


extension ShowPokemonViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apiController.pokemon.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PokemonTableViewCell", for: indexPath) as? PokemonTableViewCell else {
            print("no cell")
            return UITableViewCell()
            
        }
        let pokemon = apiController.pokemon[indexPath.row]
        cell.pokemon = pokemon
        
    return cell
}

}
